function ppuc.onCoilChanged(number, state)
  if ((number == 1 and state == 0)) and not ppuc.attractMode() then
    if ppuc.currentPlayer() == 1 then
      if ppuc.currentBall() == 1 and not ppuc.stateActive('player 1 ball 1 served') then
        ppuc.setState('player 1 ball 1 served', 60000)
        ppuc.pupTrigger('D', 60001, 1)
        ppuc.speech('Player one.')
      elseif ppuc.currentBall() == 2 and not ppuc.stateActive('player 1 ball 2 served') then
        ppuc.setState('player 1 ball 2 served', 60000)
        ppuc.pupTrigger('D', 60002, 1)
        ppuc.speech('Player one.')
      elseif ppuc.currentBall() == 3 and not ppuc.stateActive('player 1 ball 3 served') then
        ppuc.setState('player 1 ball 3 served', 60000)
        ppuc.pupTrigger('D', 60003, 1)
        ppuc.speech('Player one.')
      elseif ppuc.lampState(16) and not ppuc.stateActive('player 1 shoot again') then
        ppuc.setState('player 1 shoot again', 5000)
        ppuc.pupTrigger('D', 60016, 1)
        ppuc.speech('Player one, shoot again!')
      end
    elseif ppuc.currentPlayer() == 2 then
      if ppuc.currentBall() == 1 and not ppuc.stateActive('player 2 ball 1 served') then
        ppuc.setState('player 2 ball 1 served', 60000)
        ppuc.pupTrigger('D', 60001, 1)
        ppuc.speech('Player two.')
      elseif ppuc.currentBall() == 2 and not ppuc.stateActive('player 2 ball 2 served') then
        ppuc.setState('player 2 ball 2 served', 60000)
        ppuc.pupTrigger('D', 60002, 1)
        ppuc.speech('Player two.')
      elseif ppuc.currentBall() == 3 and not ppuc.stateActive('player 2 ball 3 served') then
        ppuc.setState('player 2 ball 3 served', 60000)
        ppuc.pupTrigger('D', 60003, 1)
        ppuc.speech('Player two.')
      elseif ppuc.lampState(16) and not ppuc.stateActive('player 2 shoot again') then
        ppuc.setState('player 2 shoot again', 5000)
        ppuc.pupTrigger('D', 60016, 1)
        ppuc.speech('Player two, shoot again!')
      end
    elseif ppuc.currentPlayer() == 3 then
      if ppuc.currentBall() == 1 and not ppuc.stateActive('player 3 ball 1 served') then
        ppuc.setState('player 3 ball 1 served', 60000)
        ppuc.pupTrigger('D', 60001, 1)
        ppuc.speech('Player three.')
      elseif ppuc.currentBall() == 2 and not ppuc.stateActive('player 3 ball 2 served') then
        ppuc.setState('player 3 ball 2 served', 60000)
        ppuc.pupTrigger('D', 60002, 1)
        ppuc.speech('Player three.')
      elseif ppuc.currentBall() == 3 and not ppuc.stateActive('player 3 ball 3 served') then
        ppuc.setState('player 3 ball 3 served', 60000)
        ppuc.pupTrigger('D', 60003, 1)
        ppuc.speech('Player three.')
      elseif ppuc.lampState(16) and not ppuc.stateActive('player 3 shoot again') then
        ppuc.setState('player 3 shoot again', 5000)
        ppuc.pupTrigger('D', 60016, 1)
        ppuc.speech('Player three, shoot again!')
      end
    elseif ppuc.currentPlayer() == 4 then
      if ppuc.currentBall() == 1 and not ppuc.stateActive('player 4 ball 1 served') then
        ppuc.setState('player 4 ball 1 served', 60000)
        ppuc.pupTrigger('D', 60001, 1)
        ppuc.speech('Player four.')
      elseif ppuc.currentBall() == 2 and not ppuc.stateActive('player 4 ball 2 served') then
        ppuc.setState('player 4 ball 2 served', 60000)
        ppuc.pupTrigger('D', 60002, 1)
        ppuc.speech('Player four.')
      elseif ppuc.currentBall() == 3 and not ppuc.stateActive('player 4 ball 3 served') then
        ppuc.setState('player 4 ball 3 served', 60000)
        ppuc.pupTrigger('D', 60003, 1)
        ppuc.speech('Player four.')
      elseif ppuc.lampState(16) and not ppuc.stateActive('player 4 shoot again') then
        ppuc.setState('player 4 shoot again', 5000)
        ppuc.pupTrigger('D', 60016, 1)
        ppuc.speech('Player four, shoot again!')
      end
    end
  elseif (number == 23 and state == 0) then
    ppuc.pupTrigger('D', 60009, 1)
    ppuc.after(3000, function()
      ppuc.speech('Game over!')
    end)
  elseif ((number == 6 and state == 1)) and not ppuc.attractMode() then
    if ppuc.onlyOnceEvery('flash effects', 4000) then
      ppuc.effectTrigger('flash-flasher', 1)
      ppuc.effectTrigger('flash-shaker', 1)
    end
  end
end
