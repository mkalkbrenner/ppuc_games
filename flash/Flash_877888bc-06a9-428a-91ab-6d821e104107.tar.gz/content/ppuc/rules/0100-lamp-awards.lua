function ppuc.onLampChanged(number, state)
  if ppuc.attractMode() then
    if ((number == 5 and state == 1)) and ppuc.onlyOnceEvery('flash attract dmd', 20000) then
      ppuc.pupTrigger('D', 60008, 1)
    end
  else
    if (number == 35 and state == 1) then
      ppuc.after(3000, function()
        ppuc.speech('Get the extra ball!')
      end)
    elseif (number == 16 and state == 1) then
      ppuc.pupTrigger('D', 60007, 1)
      ppuc.effectTrigger('extra-ball', 1)
      if ppuc.onlyOnceEvery('extra ball shaker effect', 4000) then
        ppuc.effectTrigger('extra-ball-shaker', 1)
      end
      ppuc.after(3000, function()
        ppuc.speech('Extra ball!')
      end)
    elseif (number == 14 and state == 1) then
      ppuc.after(100, function()
        ppuc.pupTrigger('D', 60005, 1)
      end)
      ppuc.after(3000, function()
        ppuc.speech('Double bonus activated!')
      end)
    elseif (number == 15 and state == 1) then
      ppuc.pupTrigger('D', 60006, 1)
      ppuc.after(3000, function()
        ppuc.speech('Tripple bonus activated!')
      end)
    elseif (number == 17 and state == 1) then
      ppuc.pupTrigger('D', 60012, 1)
    elseif (number == 18 and state == 1) then
      ppuc.pupTrigger('D', 60013, 1)
    elseif (number == 19 and state == 1) then
      ppuc.pupTrigger('D', 60014, 1)
    elseif (number == 20 and state == 1) then
      ppuc.pupTrigger('D', 60015, 1)
    elseif (number == 61 and state == 1) then
      ppuc.pupTrigger('D', 60018, 1)
    end
  end
end
