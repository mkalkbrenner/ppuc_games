function ppuc.onSwitchChanged(number, state)
  if (number == 17 and state == 1) then
    ppuc.after(1500, function()
      ppuc.speech('Test')
    end)
  end
  if not ppuc.lampState(31) and ((number == 24 and state == 0)) then
    ppuc.effectTrigger(45685, 1)
  end
end
